// ──────────────────────────────────────────────────────────
//  Promptly — Background Service Worker
//  Relays prompt-optimization requests to the Groq API.
// ──────────────────────────────────────────────────────────

const GROQ_API_URL    = "https://api.groq.com/openai/v1/chat/completions";
const GROQ_MODEL      = "llama-3.3-70b-versatile";
const MAX_INPUT_CHARS = 2000;

const SYSTEM_PROMPT =
  "You are a prompt engineering assistant. Rewrite the user's short, casual request " +
  "into a clear, well-structured prompt for an LLM. Always include: (1) the explicit " +
  "goal, (2) relevant context or constraints implied by the request, (3) a requested " +
  "output format if applicable (code, list, table, prose), (4) any tech stack or " +
  "style hints if the request is about building software or design. Keep the tone " +
  "instructional, not conversational. Do not answer the request yourself — only " +
  "rewrite it as a better prompt. Return ONLY the rewritten prompt text, no preamble, " +
  "no quotation marks, no explanation.";


// ── Helper: call the Groq API once ─────────────────────────
async function callGroqApi(apiKey, userMessage) {
  const response = await fetch(GROQ_API_URL, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${apiKey}`
    },
    body: JSON.stringify({
      model: GROQ_MODEL,
      messages: [
        { role: "system", content: SYSTEM_PROMPT },
        { role: "user",   content: userMessage    }
      ],
      temperature: 0.4
    })
  });

  if (!response.ok) {
    const errText = await response.text().catch(() => "");
    throw new Error(`API error ${response.status}: ${errText.slice(0, 200)}`);
  }

  const data = await response.json();
  const optimized = data?.choices?.[0]?.message?.content;
  if (!optimized) throw new Error("Unexpected API response shape.");
  return optimized.trim();
}

// ── Message listener ────────────────────────────────────────
chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message.type !== "OPTIMIZE_PROMPT") return false;

  const { text, projectContext } = message;

  // Async wrapper — required because onMessage must return true to keep channel open
  (async () => {
    try {
      // 1. Fetch the API key from storage
      const storage = await chrome.storage.local.get("grokApiKey");
      const apiKey  = storage.grokApiKey && storage.grokApiKey.trim();

      if (!apiKey) {
        sendResponse({
          success: false,
          error: "No API key — open the Promptly popup and enter your Groq API key in Settings."
        });
        return;
      }

      // 2. Build the user message, capping at MAX_INPUT_CHARS
      let userText = text || "";
      if (userText.length > MAX_INPUT_CHARS) {
        userText = userText.slice(0, MAX_INPUT_CHARS) + "...[truncated]";
      }

      if (projectContext && projectContext.trim() !== "") {
        userText += `\n\n${projectContext.trim()}`;
      }

      // 3. Call the API — one silent retry on 5xx
      let optimized;
      try {
        optimized = await callGroqApi(apiKey, userText);
      } catch (firstErr) {
        // Retry once on server-side errors (5xx)
        if (firstErr.message.includes("API error 5")) {
          optimized = await callGroqApi(apiKey, userText);
        } else {
          throw firstErr;
        }
      }

      sendResponse({ success: true, optimizedPrompt: optimized });
    } catch (err) {
      console.error("[Promptly] API call failed:", err);
      sendResponse({
        success: false,
        error: err.message || "Unknown error — check your API key in extension settings."
      });
    }
  })();

  // Return true to keep the message channel open for the async response
  return true;
});
