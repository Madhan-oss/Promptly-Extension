// ──────────────────────────────────────────────────────────────
//  Promptly — Popup Script (v1.1.0)
// ──────────────────────────────────────────────────────────────
'use strict';

// ════════════════════════════════════════════════════════════
//  TAB SWITCHING
// ════════════════════════════════════════════════════════════
document.querySelectorAll('.tab-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    const target = btn.dataset.tab;
    document.querySelectorAll('.tab-btn').forEach(b => {
      b.classList.remove('active');
      b.setAttribute('aria-selected', 'false');
    });
    document.querySelectorAll('.tab-content').forEach(p => p.classList.remove('active'));
    btn.classList.add('active');
    btn.setAttribute('aria-selected', 'true');
    document.getElementById(`panel-${target}`).classList.add('active');

    // Refresh history tab when opened
    if (target === 'history') loadHistory();
  });
});

// ════════════════════════════════════════════════════════════
//  HELPERS
// ════════════════════════════════════════════════════════════
function showStatus(elId, message, type, duration = 3000) {
  const el = document.getElementById(elId);
  if (!el) return;
  el.textContent = message;
  el.className = `status-msg ${type}`;
  if (duration > 0) {
    setTimeout(() => { el.className = 'status-msg'; el.textContent = ''; }, duration);
  }
}

function generateId() {
  return Math.random().toString(36).slice(2, 10) + Date.now().toString(36);
}

function escapeHtml(str) {
  if (!str) return '';
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function formatDate(iso) {
  try {
    return new Date(iso).toLocaleDateString('en-US', {
      month: 'short', day: 'numeric', year: 'numeric',
      hour: '2-digit', minute: '2-digit',
    });
  } catch (_) { return iso; }
}

// ════════════════════════════════════════════════════════════
//  SETTINGS TAB
// ════════════════════════════════════════════════════════════

const apiKeyInput  = document.getElementById('api-key-input');
const toggleKeyBtn = document.getElementById('toggle-key-visibility');
const saveKeyBtn   = document.getElementById('save-key-btn');

const EYE_OPEN = `
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"
       width="16" height="16" fill="none" stroke="currentColor"
       stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
    <path d="M1 12S5 5 12 5s11 7 11 7-4 7-11 7S1 12 1 12z"/>
    <circle cx="12" cy="12" r="3"/>
  </svg>`;

const EYE_CLOSED = `
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"
       width="16" height="16" fill="none" stroke="currentColor"
       stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
    <path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8
             a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0
             1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07
             a3 3 0 1 1-4.24-4.24"/>
    <line x1="1" y1="1" x2="23" y2="23"/>
  </svg>`;

toggleKeyBtn.addEventListener('click', () => {
  const isHidden = apiKeyInput.type === 'password';
  apiKeyInput.type = isHidden ? 'text' : 'password';
  toggleKeyBtn.innerHTML = isHidden ? EYE_CLOSED : EYE_OPEN;
  toggleKeyBtn.setAttribute('aria-label', isHidden ? 'Hide API key' : 'Show API key');
});

// Load existing key on open
chrome.storage.local.get('grokApiKey', ({ grokApiKey }) => {
  if (grokApiKey) apiKeyInput.value = grokApiKey;
});

saveKeyBtn.addEventListener('click', () => {
  const key = apiKeyInput.value.trim();
  if (!key) {
    showStatus('settings-status', '⚠️  Please enter your API key first.', 'error');
    return;
  }
  chrome.storage.local.set({ grokApiKey: key }, () => {
    showStatus('settings-status', '✅  API key saved successfully!', 'success');
  });
});

document.getElementById('get-key-link').addEventListener('click', e => {
  e.preventDefault();
  chrome.tabs.create({ url: 'https://console.groq.com/keys' });
});

// ════════════════════════════════════════════════════════════
//  PROJECTS TAB
// ════════════════════════════════════════════════════════════

const projectsList      = document.getElementById('projects-list');
const activeProjectSel  = document.getElementById('active-project-select');
const addProjectBtn     = document.getElementById('add-project-btn');
const addProjectForm    = document.getElementById('add-project-form');
const cancelProjectBtn  = document.getElementById('cancel-project-btn');
const saveProjectBtn    = document.getElementById('save-project-btn');
const projNameInput     = document.getElementById('proj-name');
const projStackInput    = document.getElementById('proj-stack');
const projToneInput     = document.getElementById('proj-tone');
const projConsInput     = document.getElementById('proj-constraints');

let editingProjectId = null;

function loadProjects() {
  chrome.storage.local.get(['projects', 'activeProjectId'], ({ projects = [], activeProjectId }) => {
    renderProjectList(projects);
    renderProjectSelect(projects, activeProjectId);
  });
}

function renderProjectSelect(projects, activeProjectId) {
  activeProjectSel.innerHTML = '<option value="">— None —</option>';
  projects.forEach(p => {
    const opt = document.createElement('option');
    opt.value = p.id;
    opt.textContent = p.name;
    if (p.id === activeProjectId) opt.selected = true;
    activeProjectSel.appendChild(opt);
  });
}

function renderProjectList(projects) {
  if (projects.length === 0) {
    projectsList.innerHTML = `
      <div class="empty-state">
        <div class="empty-icon">📋</div>
        No projects yet. Add one to give Promptly extra context.
      </div>`;
    return;
  }

  projectsList.innerHTML = '';
  projects.forEach(proj => {
    const card = document.createElement('div');
    card.className = 'project-card';
    card.dataset.id = proj.id;

    const metaParts = [];
    if (proj.stackOrDomain) metaParts.push(`<span><span class="meta-label">Stack:</span> ${escapeHtml(proj.stackOrDomain)}</span>`);
    if (proj.toneOrStyle)   metaParts.push(`<span><span class="meta-label">Style:</span> ${escapeHtml(proj.toneOrStyle)}</span>`);
    if (proj.constraints)   metaParts.push(`<span><span class="meta-label">Constraints:</span> ${escapeHtml(proj.constraints)}</span>`);

    card.innerHTML = `
      <div class="project-card-header">
        <span class="project-name">${escapeHtml(proj.name)}</span>
        <div class="project-card-actions">
          <button class="btn-icon edit-project-btn" data-id="${proj.id}" title="Edit project"
                  aria-label="Edit ${escapeHtml(proj.name)}">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="13" height="13"
                 fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/>
              <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/>
            </svg>
          </button>
          <button class="btn-danger delete-project-btn" data-id="${proj.id}"
                  aria-label="Delete ${escapeHtml(proj.name)}">Delete</button>
        </div>
      </div>
      ${metaParts.length ? `<div class="project-meta">${metaParts.join('')}</div>` : ''}
    `;
    projectsList.appendChild(card);
  });

  projectsList.querySelectorAll('.edit-project-btn').forEach(btn =>
    btn.addEventListener('click', () => startEditProject(btn.dataset.id))
  );
  projectsList.querySelectorAll('.delete-project-btn').forEach(btn =>
    btn.addEventListener('click', () => deleteProject(btn.dataset.id))
  );
}

activeProjectSel.addEventListener('change', () => {
  const id = activeProjectSel.value || null;
  chrome.storage.local.set({ activeProjectId: id });
});

function openForm(project = null) {
  editingProjectId          = project ? project.id : null;
  projNameInput.value       = project?.name          ?? '';
  projStackInput.value      = project?.stackOrDomain ?? '';
  projToneInput.value       = project?.toneOrStyle   ?? '';
  projConsInput.value       = project?.constraints   ?? '';
  saveProjectBtn.textContent = project ? 'Update Project' : 'Save Project';
  addProjectForm.classList.add('open');
  addProjectBtn.setAttribute('aria-expanded', 'true');
  projNameInput.focus();
}

function closeForm() {
  addProjectForm.classList.remove('open');
  addProjectBtn.setAttribute('aria-expanded', 'false');
  editingProjectId = null;
}

addProjectBtn.addEventListener('click', () => {
  if (addProjectForm.classList.contains('open')) closeForm();
  else openForm();
});

cancelProjectBtn.addEventListener('click', closeForm);

addProjectForm.addEventListener('submit', e => {
  e.preventDefault();
  const name = projNameInput.value.trim();
  if (!name) { projNameInput.focus(); return; }

  chrome.storage.local.get('projects', ({ projects = [] }) => {
    if (editingProjectId) {
      const idx = projects.findIndex(p => p.id === editingProjectId);
      if (idx !== -1) {
        projects[idx] = {
          ...projects[idx],
          name,
          stackOrDomain: projStackInput.value.trim(),
          toneOrStyle:   projToneInput.value.trim(),
          constraints:   projConsInput.value.trim(),
        };
      }
    } else {
      projects.push({
        id:            generateId(),
        name,
        stackOrDomain: projStackInput.value.trim(),
        toneOrStyle:   projToneInput.value.trim(),
        constraints:   projConsInput.value.trim(),
      });
    }
    chrome.storage.local.set({ projects }, () => { closeForm(); loadProjects(); });
  });
});

function startEditProject(id) {
  chrome.storage.local.get('projects', ({ projects = [] }) => {
    const proj = projects.find(p => p.id === id);
    if (proj) openForm(proj);
  });
}

function deleteProject(id) {
  chrome.storage.local.get(['projects', 'activeProjectId'], ({ projects = [], activeProjectId }) => {
    const updated   = projects.filter(p => p.id !== id);
    const newActive = activeProjectId === id ? null : activeProjectId;
    chrome.storage.local.set({ projects: updated, activeProjectId: newActive }, loadProjects);
  });
}

loadProjects();

// ════════════════════════════════════════════════════════════
//  HISTORY TAB
// ════════════════════════════════════════════════════════════

const historyList    = document.getElementById('history-list');
const clearHistoryBtn = document.getElementById('clear-history-btn');

function loadHistory() {
  chrome.storage.local.get('chatHistory', ({ chatHistory = [] }) => {
    renderHistoryList(chatHistory);
  });
}

function renderHistoryList(history) {
  if (history.length === 0) {
    historyList.innerHTML = `
      <div class="empty-state">
        <div class="empty-icon">💬</div>
        No chat exports yet.<br>
        Click the <strong>💾 Save Chat</strong> button on any AI chat page.
      </div>`;
    return;
  }

  historyList.innerHTML = '';
  history.forEach(entry => {
    const card = document.createElement('div');
    card.className = 'history-card';
    card.innerHTML = `
      <div class="history-header">
        <div class="history-platform">
          <span class="history-platform-badge">${escapeHtml(entry.platform)}</span>
          <span class="history-msg-count">${entry.messageCount} messages</span>
        </div>
        <span class="history-date">${formatDate(entry.date)}</span>
      </div>
      <div class="history-filename">${escapeHtml(entry.filename)}</div>
      <div class="history-actions">
        <button class="btn-hist-dl"   data-id="${entry.id}" title="Re-download">
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="12" height="12"
               fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
            <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
            <polyline points="7 10 12 15 17 10"/>
            <line x1="12" y1="15" x2="12" y2="3"/>
          </svg>
          Download
        </button>
        <button class="btn-hist-copy" data-id="${entry.id}" title="Copy to clipboard">
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="12" height="12"
               fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
            <rect x="9" y="9" width="13" height="13" rx="2" ry="2"/>
            <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>
          </svg>
          Copy
        </button>
        <button class="btn-hist-del"  data-id="${entry.id}" title="Delete export">
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="12" height="12"
               fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
            <polyline points="3 6 5 6 21 6"/>
            <path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/>
            <path d="M10 11v6M14 11v6"/>
          </svg>
          Delete
        </button>
      </div>
    `;
    historyList.appendChild(card);
  });

  // Wire up buttons
  historyList.querySelectorAll('.btn-hist-dl').forEach(btn =>
    btn.addEventListener('click', () => reDownloadExport(btn.dataset.id))
  );
  historyList.querySelectorAll('.btn-hist-copy').forEach(btn =>
    btn.addEventListener('click', () => copyExport(btn.dataset.id, btn))
  );
  historyList.querySelectorAll('.btn-hist-del').forEach(btn =>
    btn.addEventListener('click', () => deleteExport(btn.dataset.id))
  );
}

function reDownloadExport(id) {
  chrome.storage.local.get('chatHistory', ({ chatHistory = [] }) => {
    const entry = chatHistory.find(e => e.id === id);
    if (!entry) return;
    // Use downloads API to trigger download from popup context
    const blob = new Blob([entry.content], { type: 'text/markdown;charset=utf-8' });
    const url  = URL.createObjectURL(blob);
    const a    = document.createElement('a');
    a.href = url;
    a.download = entry.filename;
    document.body.appendChild(a);
    a.click();
    setTimeout(() => { URL.revokeObjectURL(url); a.remove(); }, 1000);
  });
}

function copyExport(id, btn) {
  chrome.storage.local.get('chatHistory', ({ chatHistory = [] }) => {
    const entry = chatHistory.find(e => e.id === id);
    if (!entry) return;
    navigator.clipboard.writeText(entry.content).then(() => {
      const orig = btn.innerHTML;
      btn.textContent = '✅ Copied!';
      setTimeout(() => { btn.innerHTML = orig; }, 2000);
    }).catch(() => {
      btn.textContent = '❌ Failed';
      setTimeout(() => { btn.innerHTML = orig; }, 2000);
    });
  });
}

function deleteExport(id) {
  chrome.storage.local.get('chatHistory', ({ chatHistory = [] }) => {
    const updated = chatHistory.filter(e => e.id !== id);
    chrome.storage.local.set({ chatHistory: updated }, loadHistory);
  });
}

clearHistoryBtn.addEventListener('click', () => {
  if (!confirm('Clear all saved chat exports?')) return;
  chrome.storage.local.set({ chatHistory: [] }, loadHistory);
});
